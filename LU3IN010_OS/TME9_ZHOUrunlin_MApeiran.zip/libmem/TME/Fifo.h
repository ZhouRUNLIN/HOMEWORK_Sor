#ifndef _FIFOSWAPPER_H_
#define _FIFOSWAPPER_H_

#include "Swapper.h"

int initFifoSwapper(Swapper*,unsigned int); //nb of physical pages

#endif
